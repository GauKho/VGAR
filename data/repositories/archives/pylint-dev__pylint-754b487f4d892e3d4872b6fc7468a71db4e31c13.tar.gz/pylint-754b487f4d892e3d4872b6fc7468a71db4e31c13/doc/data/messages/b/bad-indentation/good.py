if input():
    print('yes')
