print("%d" % 1)
