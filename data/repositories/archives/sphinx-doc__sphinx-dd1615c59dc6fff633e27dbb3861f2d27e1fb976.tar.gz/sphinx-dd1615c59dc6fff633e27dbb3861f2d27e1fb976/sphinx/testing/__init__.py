"""
    sphinx.testing
    ~~~~~~~~~~~~~~

    Sphinx test utilities

    You can require sphinx.testing pytest fixtures in a test module or a conftest
    file like this:

       pytest_plugins = 'sphinx.testing.fixtures'

    :copyright: Copyright 2007-2020 by the Sphinx team, see AUTHORS.
    :license: BSD, see LICENSE for details.
"""
