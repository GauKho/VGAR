.. cpp:var:: char c = '\\'
