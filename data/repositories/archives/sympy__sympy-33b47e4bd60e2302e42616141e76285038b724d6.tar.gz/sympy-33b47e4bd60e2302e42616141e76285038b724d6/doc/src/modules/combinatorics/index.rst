.. _combinatiorics-docs:

=============
Combinatorics
=============

Contents
========

.. toctree::
   :maxdepth: 2

   partitions.rst
   permutations.rst
   perm_groups.rst
   polyhedron.rst
   prufer.rst
   subsets.rst
   graycode.rst
   named_groups.rst
   util.rst
   group_constructs.rst
   testutil.rst
   tensor_can.rst
   fp_groups.rst
   pc_groups.rst
